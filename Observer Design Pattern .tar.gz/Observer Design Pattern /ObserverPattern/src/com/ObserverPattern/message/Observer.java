package com.ObserverPattern.message;


import com.ObserverPattern.message.Message;
/**
 * @author KK JavaTutorials
 *Observer has to fullfil this contract
 */
public interface Observer {
    public void updateObserver(Message message);
}